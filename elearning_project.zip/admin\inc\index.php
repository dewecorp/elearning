<?php
// Redirect ke main admin page
header("Location: ../index.php");
exit();
?>